package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
 
import com.nag.RestaurantBean;
 
public class RestaurantDAO
{
 
 
	  public static int addStudent1(RestaurantBean bean)
	  {
		  Connection con = null;
		  PreparedStatement pstmt = null;
		  try
		  {
 
			  con=AccountDB.getConnection(); 
			 /* String sqk="SELECT questionid.currVAL from dual";
			  pstmt = con.prepareStatement(sqk);
			  pstmt.executeQuery();*/
			  String ins_str = 
				  "insert into restaurant values(questionid.nextVAL,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
 
			  pstmt = con.prepareStatement(ins_str);
			  String q1="Restaurant Type";
			  String q2="Restaurant SQ Ft";
			  String q3="Number of Sprinklers";
			  String q4="No of Cylinders in Kitchen";
			  String q5="Fine Arts";
			  String q6="Property Damage";
			  String q7="Equipment Breakdown";
			  String q8="Liablity Coverage";
			  String q9="Bodily Injury";
 
 
 
 
			  pstmt.setString(1,q1);
			  pstmt.setString(2,bean.getRestauranttype());
 
			  pstmt.setString(3,q2);
			  pstmt.setString(4,bean.getRestaurantSQFt());
			  pstmt.setString(5,q3);
 
			  pstmt.setString(6,bean.getNumberofSprinklers());
			  pstmt.setString(7,q4);
			  pstmt.setString(8,bean.getNoofCylindersinKitchen());
			  pstmt.setString(9,q5);
			  pstmt.setString(10,bean.getFineArts());
			  pstmt.setString(11,q6);
			  pstmt.setString(12,bean.getPropertyDamage());
			  pstmt.setString(13,q7);
			  pstmt.setString(14,bean.getEquipmentBreakdown());
			  pstmt.setString(15,q6);
			  pstmt.setString(16,bean.getLiablityCoverage());
			  pstmt.setString(17,q7);
			  pstmt.setString(18,bean.getBodilyInjury());
 
			  pstmt.setInt(19,bean.getAccount_number());
 
 
 
			  int updateCount = pstmt.executeUpdate();
 
			  con.close();
 
			  return updateCount;
 
 
		  }
		  catch(Exception ex)
		  {
			  System.out.println(ex.toString());
			  return 0;
		  }
 
	  }
	}
