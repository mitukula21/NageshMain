package com.nag;

public class RestaurantBean
{
	private String restauranttype;
	private String restaurantSQFt;
	private String numberofSprinklers;
	private String noofCylindersinKitchen;
	private String fineArts;
	private String propertyDamage;
	private String equipmentBreakdown;
	private String liablityCoverage;
	private String bodilyInjury;
	private int account_number;
	public String getRestauranttype() {
		return restauranttype;
	}
	public void setRestauranttype(String restauranttype) {
		this.restauranttype = restauranttype;
	}
	public String getRestaurantSQFt() {
		return restaurantSQFt;
	}
	public void setRestaurantSQFt(String restaurantSQFt) {
		this.restaurantSQFt = restaurantSQFt;
	}
	public String getNumberofSprinklers() {
		return numberofSprinklers;
	}
	public void setNumberofSprinklers(String numberofSprinklers) {
		this.numberofSprinklers = numberofSprinklers;
	}
	public String getNoofCylindersinKitchen() {
		return noofCylindersinKitchen;
	}
	public void setNoofCylindersinKitchen(String noofCylindersinKitchen) {
		this.noofCylindersinKitchen = noofCylindersinKitchen;
	}
	public String getFineArts() {
		return fineArts;
	}
	public void setFineArts(String fineArts) {
		this.fineArts = fineArts;
	}
	public String getPropertyDamage() {
		return propertyDamage;
	}
	public void setPropertyDamage(String propertyDamage) {
		this.propertyDamage = propertyDamage;
	}
	public String getEquipmentBreakdown() {
		return equipmentBreakdown;
	}
	public void setEquipmentBreakdown(String equipmentBreakdown) {
		this.equipmentBreakdown = equipmentBreakdown;
	}
	public String getLiablityCoverage() {
		return liablityCoverage;
	}
	public void setLiablityCoverage(String liablityCoverage) {
		this.liablityCoverage = liablityCoverage;
	}
	public String getBodilyInjury() {
		return bodilyInjury;
	}
	public void setBodilyInjury(String bodilyInjury) {
		this.bodilyInjury = bodilyInjury;
	}
	public int getAccount_number() {
		return account_number;
	}
	public void setAccount_number(int account_number) {
		this.account_number = account_number;
	}
 
 
 
 
}
