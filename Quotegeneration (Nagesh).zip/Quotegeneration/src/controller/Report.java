package controller;




	import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;

	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	@WebServlet("/Report")
	public class Report extends HttpServlet
	{
		private static final long serialVersionUID = 1L;
	 
	    public Report() {
	        super();
	        // TODO Auto-generated constructor stub
	    }
	 
		/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			response.getWriter().append("Served at: ").append(request.getContextPath());
		}*/
	 
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			//doGet(request, response);
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
	 
			/*String ID = request.getParameter("id");
			int id = Integer.parseInt(ID);*/
	        
			try { 
				Class.forName("oracle.jdbc.OracleDriver");
			
				Connection con = DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521/orcl","trg629","training629");
				PreparedStatement ps = con.prepareStatement("select accountcreation.insured_name,businessauto1.question_id,"
						+ "businessauto1.account_number from businessauto1 "
						+ "full outer join accountcreation on "
						+ "accountcreation.account_number=businessauto1.account_number");
				//PreparedStatement ps1 = con.prepareStatement("select sum(vehicletype+vehiclemy+vehiclemodel+dailycd+servicecenter+limit+limit2) from businessauto1 where account_number=?");
				//ps.setInt(1, id);
				//ps1.setInt(1, id);
				
	 
				ResultSet rs = ps.executeQuery();
				//"<h5>InsuredName: </h5>" +"<h6>"+rs.getString(1)+"</h6>" + " <h5>PolicyId: </h5>"+"<h6>"+ rs.getInt(2) +"</h6>"+ "<h5>Account_number:</h5>" +"<h6>"+ rs.getInt(3)+"<h6>"
				while (rs.next()) {
					out.println("InsuredName:"+rs.getString(1) +"      PolicyId:"+ rs.getInt(2) + "       Account_number" + rs.getInt(3)+"<br><br>");
							
					
				}
				//ResultSet rs1 = ps1.executeQuery();
				 
				/*while (rs1.next()) 
				{
					out.println("</br>Premium:"+rs1.getInt(1));
				}
				out.println("</br></br><a href='Admin.jsp'>Return to admin</a>");*/
				out.println("<br><br><form action=\"Fetch\" method=\"post\">\r\n" + 
						"		Enter the Account Number you want to search: <input type=\"text\" name=\"id\"> <br>\r\n" + 
						"							<input type=\"submit\" value=\"search\">\r\n" + 
						"</form>");
			} 
			
			
			catch (Exception e) {
				e.printStackTrace();
			} finally {
				out.close();
			}
			System.out.println("retrieved data");
		
		}
	 
	}


